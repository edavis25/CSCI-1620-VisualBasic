﻿Public Class BaseForm


    Public Overridable Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click
        ' The overridable nature of this procedure allows other classes to use the OK button in different ways.

    End Sub

    
End Class