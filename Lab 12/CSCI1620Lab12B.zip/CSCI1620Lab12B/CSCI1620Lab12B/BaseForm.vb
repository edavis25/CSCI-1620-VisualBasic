﻿Public Class BaseForm

    Public Overridable Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click

        'Allow the inherited classes to override this method to allow different uses for OK button.

    End Sub
End Class